﻿using System.Windows.Controls;

namespace $safeprojectname$.Dialogs
{
    /// <summary>
    /// Interaction logic for DefaultUserConfirmationDialogView.xaml
    /// </summary>
    public partial class DefaultUserConfirmationDialogView : UserControl
    {
        public DefaultUserConfirmationDialogView()
        {
            InitializeComponent();
        }
    }
}
