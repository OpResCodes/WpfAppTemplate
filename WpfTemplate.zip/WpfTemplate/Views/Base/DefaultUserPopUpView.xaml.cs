﻿using System.Windows.Controls;

namespace $safeprojectname$.Dialogs
{
    /// <summary>
    /// Interaction logic for DefaultUserPopUpView.xaml
    /// </summary>
    public partial class DefaultUserPopUpView : UserControl
    {
        public DefaultUserPopUpView()
        {
            InitializeComponent();
        }
    }
}
