﻿using System.Windows.Controls;

namespace $safeprojectname$.Views.Base
{
    /// <summary>
    /// Interaction logic for SimpleChart.xaml
    /// </summary>
    public partial class SimpleChart : UserControl
    {
        public SimpleChart()
        {
            InitializeComponent();
        }
    }
}
