﻿using System.Windows.Controls;

namespace $safeprojectname$.Dialogs
{
    /// <summary>
    /// Interaction logic for ProgressReportView.xaml
    /// </summary>
    public partial class DefaultProgressReportPopup : UserControl
    {
        public DefaultProgressReportPopup()
        {
            InitializeComponent();
        }
    }
}
