﻿using NLog;
using System.Windows.Controls;

namespace $safeprojectname$.Views.Base
{

    /// <summary>
    /// Interaction logic for LogView.xaml
    /// </summary>
    public partial class LogView : UserControl
    {
        public LogView()
        {
            InitializeComponent();
            LogManager.GetCurrentClassLogger().Debug("LogView ready.");
        }
    }



}
