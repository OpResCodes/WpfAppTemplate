﻿using System;

namespace $safeprojectname$.Utilities.ExceptionHandling
{
    public interface IExceptionHandler
    {
        void HandleException(Exception ex);
    }
}