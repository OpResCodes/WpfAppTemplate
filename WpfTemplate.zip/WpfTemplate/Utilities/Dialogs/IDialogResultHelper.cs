﻿using System;

namespace $safeprojectname$.Dialogs
{
    public interface IDialogResultHelper
    {
        void CloseDialog(bool withResult = false);
        event EventHandler<RequestCloseEventArgs> RequestCloseDialog;
    }
}
