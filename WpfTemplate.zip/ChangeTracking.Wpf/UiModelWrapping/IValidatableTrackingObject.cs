﻿using System.ComponentModel;

namespace $safeprojectname$
{
    public interface IValidatableTrackingObject : IRevertibleChangeTracking, INotifyPropertyChanged
    {
        bool IsValid { get; }

    }
}
